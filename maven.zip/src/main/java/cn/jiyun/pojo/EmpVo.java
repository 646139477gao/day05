package cn.jiyun.pojo;

public class EmpVo extends Emp {
	
	private String dname;

	public String getDname() {
		return dname;
	}

	public void setDname(String dname) {
		this.dname = dname;
	}
	
}
