package cn.jiyun.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.github.pagehelper.PageInfo;

import cn.jiyun.pojo.EmpVo;
import cn.jiyun.service.EmpService;

@Controller
@RequestMapping("emp")
public class EmpController {
	@Autowired
	private EmpService empService;

	@RequestMapping("findPage")
	@ResponseBody
	public PageInfo<EmpVo> findPade(@RequestParam(defaultValue = "1") int pageNum,
			@RequestParam(defaultValue = "2") int pageSize) {

		return empService.findPage(new EmpVo(), pageNum, pageSize);

	}
}
