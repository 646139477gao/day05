package cn.jiyun.mapper;

import java.util.List;

import cn.jiyun.pojo.EmpVo;

public interface EmpMapper {
	public List<EmpVo>findEmp(EmpVo empVo);
}
