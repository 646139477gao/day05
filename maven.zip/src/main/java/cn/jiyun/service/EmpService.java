package cn.jiyun.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;

import cn.jiyun.mapper.EmpMapper;
import cn.jiyun.pojo.EmpVo;

@Service
public class EmpService {
  @Autowired
  private EmpMapper empMapper;
   public PageInfo<EmpVo> findPage(EmpVo empVo,int pageNum, int pageSize){
	   PageHelper.startPage(pageNum,pageSize);
	   List<EmpVo> list = empMapper.findEmp(empVo);	   
	   return new PageInfo<EmpVo>(list);
			  
   }
}
